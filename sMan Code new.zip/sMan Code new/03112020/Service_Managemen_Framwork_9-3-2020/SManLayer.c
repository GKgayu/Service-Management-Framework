

/*****------------~~~~~~~~~~~~~~Server Management Framwork~~~~~~~~~~~~~~~~~~...........******/
/*--------Standard include files------------------------*/
/*--------Server management headerfile------------------*/



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <linux/types.h>
#include <asm/types.h>
#include <linux/socket.h>
#include <asm/socket.h>
#include <netinet/in.h>
#include "server_framework.h"

#define SERVER_PORT 1070
 

#define NOT_OPERATIONAL 0;
#define STARTING_UP 1;
#define ACTIVE 2;
#define CLOSING 3;
#define CLOSED 4;

/* Global variables */

unsigned int service_id_next = 1;

struct service_management_framework smf;

//Printf for debugging

int print_service_management_framework(struct service_management_framework * psmf) 
{
int i;
char smf_name[100];
char service_name[100];
char archive_name[100];

struct service *pserv;

strncpy(smf_name, psmf->smf_name, psmf->smf_name_len);
printf("Service Management Frameowork Name %s\n", smf_name);
printf("smf.status is: %d \n ", psmf->status);
if(psmf->list_managed_services.count > 0 )
{
  pserv = psmf->list_managed_services.head;
  for(i = 0; i < psmf->list_managed_services.count; i++)
  {
   printf("service_name_len %d \n", pserv->service_name_len);
   strncpy(service_name, pserv->service_name, pserv->service_name_len);
   printf("service_name:%s\n",service_name);
   printf("archive_executable_len %d \n", pserv->archive_executable_len);
   strncpy(archive_name, pserv->archive_executable, pserv->archive_executable_len);
   printf("archive_name:%s \n", archive_name);
   printf("service_id %d", pserv->service_id);
   printf("service_version: %d \n" , pserv->service_version);
   printf("maximum_number_servers: %d \n " , pserv->maximum_number_servers);
   printf("current_number_servers: %d \n " , pserv->current_number_servers);
   printf("service_list_count; %d \n " , pserv->service_server_list.count);
   printf("service_resources_required.CPU %d \n " , pserv->service_resources_required.CPU);
   printf("service_resources_required.memory %d \n " , pserv->service_resources_required.memory);
   printf("service_resources_required.network %d \n " , pserv->service_resources_required.network);
   printf("service_resources_required.storage %d \n " , pserv->service_resources_required.storage);
   printf("service_qos.latency %d \n " , pserv->service_qos.latency);
   printf("service_qos.bandwidth %d \n " , pserv->service_qos.bandwidth);
   printf("service_qos.jitter %d \n " , pserv->service_qos.jitter);
   printf("service_qos.reliability %d \n " , pserv->service_qos.reliability);
   printf("Finish printing service %d\n", pserv->service_id);
   pserv = pserv->next;
  }
 
}
  else 
  {
    printf(" No services recorded ");
   }
 return 0;
 }



/*Need to define a set of calls to the SMF*/
/* The first call is registered service. Actual call is */
/*int register_service ( struct service *svr);
return service_ID;

/* The next call is update service.*/
/*
int update_service ( struct service *svr);
Return 1 for success, 0 for failure;*/

/* delete service */
/*
int delete_service ( struct service *svr);
int shutdown_service ( struct service *svr);
int restart_service ( struct service *svr); */


/* service interfaces described in the paper- normally we do the application interface */

unsigned int request_service ( char *svr_name, int svr_version, struct qos *, unsigned int ip_addr, unsigned char *mac_addr, struct service_min **ppsm);


/*step5 – Returns a node_ ID, service_name, service _id, location, qos requirements and server ip address….. we need to allow SCS talk to the SManL. When a ping fails, we get a message from SCS. Lets suppose, the SCS came back and said the pinging or the client failed. We need to find the service that associated with the Client.  */

/*int find_new_server_for_Client ( struct client *, struct service * svr)


/* We need to return a server structure from the call. 

int migrate_service ( struct service *svr , unsigned int ip_addr, unsigned short svr_port);

/*return 1 if it is successful or 0 for failure.



/* ------------------- outer interface - calls from the outside -------------------------------------------*/
/*
int register_service ( struct service *svr);

int update_service ( struct service *svr);

int delete_service ( struct service *svr);

int shutdown_service ( struct service *svr);

int restart_service ( struct service *svr);

int Request_service ( char *svr_name, int svr_version, struct qos *, unsigned int ip_addr, unsigned char *mac_addr);

int find_new_server_for_Client ( struct client *, struct service * svr);

int migrate_service ( struct service *svr , unsigned int ip_addr, unsigned short svr_port); */


/* --------------------------------Inner interface routines --------------------------------------------------*/
/* new service structure */
int get_new_service_srtuct ( struct service **);
int get_new_server_struct (struct server **);
int get_new_client_struct (struct client **);
int get_new_qos_struct (struct qos **);
int get_new_restriction_list_struct (struct restriction_list **);
int get_new_recovery_mechanism_struct (struct recovery_mechanism **);

/* new delete structure */
int delete_service_struct ( struct service *);
int delete_server_struct (struct server *);
int delete_client_struct (struct client *);
int delete_qos_struct (struct qos *);
int delete_restriction_list_struct (struct restriction_list *);
int delete_recovery_mechanism_struct (struct recovery_mechanism *);


/* new queue_service structure */
int queue_service_list ( struct service *, struct service_list *);
int queue_server_list ( struct server *, struct server_list *);
int queue_client_list ( struct client *, struct client_list *);

/* new find_service structure */
int find_service ( int service_id, struct service ** svr, struct service_list *);
int find_server ( int server_id, struct server ** svr, struct server_list *);
int find_client (int client_id, struct client ** clnt, struct client_list *);




/*---------------------------------- Inner interface routines _ Programs-------------------------------------------------*/


/*.........................................new service structure  ......................................*/

/* new service structure */
int get_new_service_srtuct ( struct service **ppsvr)
{
struct service *lsvr; 				/* l-local */
int result = -1;

if (( lsvr = ( struct service * ) malloc (sizeof(struct service))) == NULL)
return result;

else {
 result = 0;
*ppsvr = lsvr;
}

return result ;
}



/* new server structure -(int get_new_server_struct (struct server **);) */
int get_new_server_struct ( struct server  **ppserv)
{
struct server *lservr; 				/* l-local */
int result = -1;

if (( lservr = ( struct server * ) malloc (sizeof ( struct server))) == NULL)
return result;

else {
 result = 0;
* ppserv = lservr;
}

return result ;
}



/* new Client structure - (int get_new_client_struct (struct client **);) */
int get_new_client_srtuct ( struct client **ppclit)
{
struct client *lclit; 				/* l-local */
int result = -1;

if (( lclit = ( struct client * ) malloc (sizeof ( struct client))) == NULL)
return result;

else {
 result = 0;
*ppclit = lclit;
}

return result ;
}


/* new new qos structure - (int get_new_qos_struct (struct qos **);) */
int get_new_qos_srtuct ( struct qos **ppqos)
{
struct qos *lqos; 				/* l-local */
int result = -1;

if (( lqos = ( struct qos * ) malloc (sizeof ( struct qos))) == NULL)
return result;

else {
 result = 0;
*ppqos = lqos;
}

return result ;
}

 

/* new restriction structure - (int get_new_restriction_struct (struct restriction **);) */

int get_new_restriction_list_srtuct ( struct restriction_list **pprestr)
{
struct restriction_list *lrestr; 				/* l-local */
int result = -1;

if ((lrestr = ( struct restriction_list * ) malloc ( sizeof ( struct restriction_list))) == NULL)
return result;

else {
 result = 0;
*pprestr = lrestr;
}

return result ;
}




/* new get_new_Recovery_Mechanism - (int get_new_Recovery_Mechanism_struct (struct rec_mech **);) */

int get_new_recovery_mechanism_srtuct ( struct recovery_mechanism **pprec_mec)
{
struct recovery_mechanism *lrec_mec; 				/* l-local */
int result = -1;

if (( lrec_mec = ( struct recovery_mechanism * ) malloc (sizeof ( struct recovery_mechanism))) == NULL)
return result;

else {
 result = 0;
*pprec_mec = lrec_mec;
}

return result ;
}

 
/*........................new delete Structure .................................................................*/

 

/* quick delete need to check status before deleting - (int delete_service_struct ( struct service * del_svr);) */

int delete_service_struct ( struct service *del_svr)
{
if(del_svr != NULL) 
{
free((void *) del_svr);
return 0;
} 
else 
return -1;
}


/* quick delete need to check status before deleting - (int delete_server_struct (struct server *)) */

int delete_server_struct ( struct server *del_servr)

{
if (del_servr != NULL) 
{
free ((void *) del_servr);
return 0; 
}
else
return -1;
}

/* quick delete need to check status before deleting - (int delete_client_struct (struct client *);) */

int delete_client_struct ( struct client *del_clit)

{
if (del_clit != NULL) 
{
free ((void *) del_clit);
return 0; 
}
else 
return -1;

}



/* quick delete need to check status before deleting - (int delete_qos_struct (struct qos *);) */

int delete_qos_struct ( struct qos *del_qos)

{
if (del_qos != NULL)
{
free ((void *) del_qos);
return 0; 
}
else 
return -1;
}
  



/* quick delete need to check status before deleting - (int delete_restriction_struct (struct restriction *);) */

int delete_restriction_list_struct ( struct restriction_list *del_restr)

{
if (del_restr != NULL)
{
free ((void *) del_restr);
return 0; 
}
else 
return -1;
}



/* quick delete need to check status before deleting - (int delete_Recovery_Mechanism_struct (struct rec_mech *);) */

int delete_recovery_mechanism_struct ( struct recovery_mechanism *del_rec_mech)

{
if (del_rec_mech != NULL)
{
free ((void *) del_rec_mech);
return 0; 
}
else
return -1;
}

/*.........................new queue_service structure  ......................................*/

/* queue service* - (int queue_service_list ( struct service *, struct service_list *);)------*/


int queue_service_list ( struct service *serv, struct service_list *servl)
{	
if ((serv == NULL) || (servl == NULL))
return -1;
else if (servl-> count == 0)
servl->head = servl->tail = serv;
else 
{
servl->tail->next = serv;
serv->prev = servl->tail;
serv->next = NULL;
}
servl->count++;
return 0;
}

/* queue queue_server_list* - (int queue_server_list ( struct server *, struct Server_list *);) */

int queue_server_list ( struct server *servr, struct server_list *servrl)
{	
if ((servr == NULL) || (servrl == NULL))
return -1;
else if (servrl -> count == 0)
servrl ->head = servrl ->tail = servr;
else 
{
servrl ->tail->next = servr;
servr->prev = servrl->tail;
servr->next = NULL;
}
servrl->count++;
return 0;
}

/* queue queue_client_list* -  (int queue_client_list ( struct client *, struct Client_list *);) */

int queue_client_list ( struct client *clit, struct client_list *clitl)
{	
if ((clit == NULL) || (clitl == NULL))
return -1;
else if (clitl-> count == 0)
clitl->head = clitl->tail = clit;
else 
{
clitl->tail->next = clit;
clit->prev = clitl->tail;
clit->next = NULL;
clitl->tail = clit;
}
clitl->count++;
return 0;
}


/* dequeue service*/

int dequeue_service_list ( struct service *serv, struct service_list *servl)
{
if (serv == servl->head)
{
servl->head = serv->next;
if (servl-> head != NULL)
{
servl->head-> prev = NULL;
}
else
 servl->tail = NULL;
}
else if (serv != servl->tail )
{
serv->prev->next = serv->next;
serv->next->prev = serv->prev;
}
else 
{
/* I am a tail*/
servl->tail = serv->prev;
servl->tail->next = NULL;
}

servl->count++;
serv->next = serv->prev = NULL;
return 0;
}



/*.....................new find_service structure  ......................................*/

/*~~~~~~~~~~~~~~~~~~~~~~~ find service by number and find service by names ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*find service by number - (int find_service_by_number ( int service_id, struct service ** svr, struct service_list *);) */


int find_service_by_number ( int service_id, struct service **ppserv, struct service_list *servl)
{
struct service *pserv;

pserv = servl->head;


while(pserv != NULL)
{

if (pserv->service_id == service_id)
{
*ppserv = pserv;
return 0;
}
else
{

pserv = pserv->next;
}
}
return -1;
}

/*find_server_by_number - (int find_server ( int server_id, struct server ** svr, struct server_list *);) */


int find_server_by_number ( int server_id, struct server **ppservr, struct server_list *servrl)
{
struct server *pservr;
pservr = servrl->head;

while(pservr != NULL)
{

if (pservr->server_id == server_id)
{
*ppservr = pservr;
return 0;
}
else
{

pservr = pservr->next;
}
}
return -1;
}

/*find client by number - (int find_client (int client_id, struct client ** clnt, struct client_list *);) */



int find_client_by_number ( int client_id, struct client **ppclit, struct client_list *clitl)
{
struct client *pclit;

pclit = clitl->head;

while(pclit != NULL)
{

if (pclit->client_id == client_id)
{
*ppclit = pclit;
return 0;
}
else
{

pclit = pclit->next;
}
}
return -1;
}

/*~~~~~~~~~~~~~~~~~~~~~~~ find service by name  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*
int find_service ( int service_id, struct service ** svr, struct service_list *);
int find_server ( int server_id, struct server ** svr, struct server_list *);
int find_client (int client_id, struct client ** clnt, struct client_list *); */



/*find service by name - (int find_service_by_number ( int service_id, struct service ** svr, struct service_list *);) */


int find_service_by_name ( char *service_name, struct service **ppserv, struct service_list *servl)
{

struct service *pserv;

pserv = servl->head;


while(pserv != NULL)
{

if ((strcmp(pserv->service_name, service_name)) == 0)
{
*ppserv = pserv;
return 0;
}
else
{

pserv = pserv->next;
}
}
return -1;
}

/* we are now going to implement the outer routines 
/*server interface
int register_service ( struct service *svr);

int update_service ( struct service *svr);

int delete_service ( struct service *svr);

int shutdown_service ( struct service *svr);

int restart_service ( struct service *svr);
/*client interface
int Request_service ( char *svr_name, int svr_version, struct qos *, unsigned int ip_addr, unsigned char *mac_addr);

int find_new_server_for_Client ( struct client *, struct service * svr)

int migrate_service ( struct service *svr , unsigned int ip_addr, unsigned short svr_port); */


/* register service */

int register_service (struct service *svr)
{ 
struct service *psvr;
int i = 0;

if((find_service_by_name ( svr->service_name, &psvr, &smf.list_managed_services)) == 0)
{
return(psvr-> service_id); /*already there*/
}
else if ((get_new_service_srtuct (&psvr)) < 0)
/* creating  new service */
{
printf("get_new_service_srtuct - Unable ot get service");
return -1;

}
else 
{
printf("Register service Creating service \n");

psvr->service_name_len = svr->service_name_len;
strncpy (psvr->service_name, svr->service_name,psvr->service_name_len);

psvr->service_id = service_id_next++;
svr->service_id = psvr->service_id;
psvr->archive_executable_len = svr-> archive_executable_len;
strncpy (psvr->archive_executable, svr->archive_executable,psvr->archive_executable_len);

psvr->service_version = svr-> service_version;
psvr->maximum_number_servers = svr->maximum_number_servers;
psvr->current_number_servers = 0;
psvr->service_server_list.head = psvr->service_server_list.tail = NULL;
psvr->service_server_list.count = 0;

psvr->service_resources_required.CPU = svr->service_resources_required.CPU;
psvr->service_resources_required.memory = svr->service_resources_required.memory;
psvr->service_resources_required.network = svr->service_resources_required.network;
psvr->service_resources_required.storage = svr->service_resources_required.storage;

psvr->service_qos.latency = svr->service_qos.latency;
psvr->service_qos.bandwidth = svr->service_qos.bandwidth;
psvr->service_qos.jitter = svr->service_qos.jitter;
psvr->service_qos.reliability = svr->service_qos.reliability;
/*
psvr->service_restriction_list.security_level = svr->service_restriction_list.security_level;
psvr->service_restriction_list.maximum_replication = svr->service_restriction_list.maximum_replication;

psvr->service_restriction_list.qos_min.latency = svr->service_restriction_list.qos_min.latency;
psvr->service_restriction_list.qos_min.bandwidth = svr->service_restriction_list.qos_min.bandwidth;
psvr->service_restriction_list.qos_min.jitter = svr->service_restriction_list.qos_min.jitter;
psvr->service_restriction_list.qos_min.reliability = svr->service_restriction_list.qos_min.reliability;

psvr->service_restriction_list.restrict_array_count = svr->service_restriction_list.restrict_array_count;

if (psvr->service_restriction_list.restrict_array_count != 0)
{

for (i = 0; i<psvr->service_restriction_list.restrict_array_count; i++)
{
psvr->service_restriction_list.location[i] = svr->service_restriction_list.location[i];
}

psvr->service_network_requirments.types_of_handover_support = svr->service_network_requirments.types_of_handover_support;

psvr->service_network_requirments.signalling_from_network_layer = svr->service_network_requirments.signalling_from_network_layer;

psvr->service_network_requirments.list_of_network_interfaces = svr->service_network_requirments.list_of_network_interfaces;

psvr->service_network_requirments.list_of_transport_protocol =svr->service_network_requirments.list_of_transport_protocol;

psvr->service_restrictions_max.max_CPU = svr->service_restrictions_max.max_CPU;
psvr->service_restrictions_max.max_memory = svr->service_restrictions_max.max_memory;
psvr->service_restrictions_max.max_storage = svr->service_restrictions_max.max_storage;

psvr->service_recovery_mechanism.shutdown = svr->service_recovery_mechanism.shutdown;
psvr->service_recovery_mechanism.restart = svr->service_recovery_mechanism.restart;
}*/
psvr->next = NULL;
psvr->prev = NULL; 
 
/* Initization completed. Now we queue */
printf("Queuing New service on list of managed services");
queue_service_list (psvr, &smf.list_managed_services);
return psvr-> service_id;


}


/* delete service - int delete_service ( struct service *svr);) */

int delete_service ( struct service *svr)
{
struct service *psvr;

if ((find_service_by_number (svr->service_id, &psvr, &smf.list_managed_services)) == 0)
{
/* first dequeue service */
dequeue_service_list(psvr, &smf.list_managed_services);
printf("Deleting service by number: %d", psvr->service_id);
delete_service_struct (psvr);
return 0;
}
else if((find_service_by_name (svr->service_name, &psvr, &smf.list_managed_services)) == 0)

{
dequeue_service_list(psvr, &smf.list_managed_services);
printf("Deleting service by name: %s", psvr->service_name);
delete_service_struct (psvr);
return 0;
}
else

{
printf("unable to delete service %d, %s", svr->service_id,svr->service_name);
return -1;
}
}




/* update service - (int update_service ( struct service *svr);) */

int update_service ( struct service *svr)
{
struct service *psvr;

if ((find_service_by_number (svr->service_id, &psvr, &smf.list_managed_services)) == 0)
{
/* first dequeue service */
dequeue_service_list(psvr, &smf.list_managed_services);
}
else if((find_service_by_name (svr->service_name, &psvr, &smf.list_managed_services)) == 0)

{
dequeue_service_list(psvr, &smf.list_managed_services);
}
else

{
printf("unable to find existing service %d, %s", svr->service_id,svr->service_name);
return -1;
}

strcpy (psvr->archive_executable, svr->archive_executable);
psvr->service_version = svr-> service_version;
psvr->maximum_number_servers = svr->maximum_number_servers;
psvr->current_number_servers = 0;
psvr->service_server_list.head = psvr->service_server_list.tail = NULL;
psvr->service_server_list.count = 0;

psvr->service_resources_required.CPU = svr->service_resources_required.CPU;
psvr->service_resources_required.memory = svr->service_resources_required.memory;
psvr->service_resources_required.network = svr->service_resources_required.network;
psvr->service_resources_required.storage = svr->service_resources_required.storage;

psvr->service_qos.latency = svr->service_qos.latency;
psvr->service_qos.bandwidth = svr->service_qos.bandwidth;
psvr->service_qos.jitter = svr->service_qos.jitter;
psvr->service_qos.reliability = svr->service_qos.reliability;

psvr->service_restriction_list.security_level = svr->service_restriction_list.security_level;
psvr->service_restriction_list.maximum_replication = svr->service_restriction_list.maximum_replication;
psvr->service_restriction_list.qos_min.latency = svr->service_restriction_list.qos_min.latency;
psvr->service_restriction_list.qos_min.bandwidth = svr->service_restriction_list.qos_min.bandwidth;
psvr->service_restriction_list.qos_min.jitter = svr->service_restriction_list.qos_min.jitter;
psvr->service_restriction_list.qos_min.reliability = svr->service_restriction_list.qos_min.reliability;

psvr->service_restriction_list.restrict_array_count = svr->service_restriction_list.restrict_array_count;

if (psvr->service_restriction_list.restrict_array_count != 0)
{

for (i = 0; i<psvr->service_restriction_list.restrict_array_count; i++)
{
psvr->service_restriction_list.location[i] = svr->service_restriction_list.location[i];
}

psvr->service_network_requirments.types_of_handover_support = svr-> service_network_requirments.types_of_handover_support;

psvr->service_network_requirments.signalling_from_network_layer =svr->service_network_requirments.signalling_from_network_layer;

psvr->service_network_requirments.list_of_network_interfaces =svr->service_network_requirments.list_of_network_interfaces;

psvr->service_network_requirments.list_of_transport_protocol =svr->service_network_requirments.list_of_transport_protocol;

psvr->service_restrictions_max.max_CPU = svr->service_restrictions_max.max_CPU;
psvr->service_restrictions_max.max_memory = svr->service_restrictions_max.max_memory;
psvr->service_restrictions_max.max_storage = svr->service_restrictions_max.max_storage;

psvr->service_recovery_mechanism.shutdown = svr->service_recovery_mechanism.shutdown;
psvr->service_recovery_mechanism.restart = svr->service_recovery_mechanism.restart;


psvr->next = NULL;
psvr->prev = NULL;

/* Initization completed. Now we queue */
queue_service_list (psvr, &smf.list_managed_services);
return psvr-> service_id;

}
}
}

/* shutdown the service - (int shutdown_service ( struct service *svr); */
/* int shutdown_service ( struct service *svr)*/

int shutdown_service (struct service *svr) 
{
struct service *psvr;
if ((find_service_by_number (svr->service_id, &psvr, &smf.list_managed_services)) == 0)
{
}
else if((find_service_by_name (svr->service_name, &psvr, &smf.list_managed_services)) == 0)
{
}
else
{
printf("unable to find existing service %d, %s", svr->service_id,svr->service_name);
return -1;
}

printf("Found the service %s", psvr->service_name);

if (psvr->service_recovery_mechanism.shutdown == 0)
{
printf("Service manangement framwork cannot shutdown the service");
return -1;
}
else
{ 
printf("Service manangement framwork can shutdown the service");
/*instruct OS to shutdown the services*/
}
}

/* restart a service - int restart_service ( struct service *svr);) */


int restart_service (struct service *svr)
{
struct service *psvr;

if ((find_service_by_number (svr->service_id, &psvr, &smf.list_managed_services)) == 0)
{
}
else if((find_service_by_name (svr->service_name, &psvr, &smf.list_managed_services)) == 0)
{
}
else

{
printf("unable to find existing service %d, %s", svr->service_id,svr->service_name);
return -1;
}

printf("Found the service %s", psvr->service_name);

if (psvr->service_recovery_mechanism.restart == 0)
{
printf("Service manangement framwork cannot restart the service");
return -1;
}
else
{ 
printf("Service manangement framwork can restart the service");
/*instruct OS to restart the services*/
}
}

//simple service code
unsigned int request_service_simple ( char *svr_name, int svr_version, struct service **ppserv )
{
struct service *psvr;
if((find_service_by_name(svr_name, &psvr, &smf.list_managed_services)) < 0)
{
printf("Unable to find service %s", svr_name) ;
return 0;
}
if (psvr->service_version != svr_version)
{
printf("Server Versions do not match");
return 0;
}
*ppserv = psvr;
return 1;
}
/*#####   Client interface  ########*/
/* request a service - (int Request_service ( char *svr_name, int svr_version, struct qos *, unsigned int ip_addr, unsigned char *mac_addr);)*/

unsigned int request_service ( char *svr_name, int svr_version, struct qos *svrqos, unsigned int ip_addr, unsigned char *mac_addr, struct service_min **ppsm)


{
struct service *psvr;
struct service_min *psm;
if((find_service_by_name(svr_name, &psvr, &smf.list_managed_services)) < 0)
{
printf("Unable to find service %s", svr_name) ;
return 0;
}
if (psvr->service_version != svr_version)
{
printf("Server Versions do not match");
}

if (psvr->service_qos.latency > svrqos->latency)  /*smf latency */ 
{
printf("Latency is less than the server can provide");
return 0;
}
if (psvr->service_qos.bandwidth < svrqos->bandwidth)  
{
printf("bandwidth is greater than the server can provide");
return 0;
}
if (psvr->service_qos.jitter > svrqos->jitter)  
{
printf("jitter is lesser than the server can provide");
return 0;
}
if (psvr->service_qos.reliability > svrqos->reliability)  
{
printf("reliabilty is greater than the server can provide");
return 0;
}/* We need to apply RASP Protocol */
if ((psm = malloc (sizeof(struct service_min))) == NULL)
{
printf("Unable to get the service"); 
return 0;
}
else 
{
printf("Unable to find the service %s", svr_name);/* we cant find the service, so we cant allocate it*/ 
return 0;
}
return 1;
}


/* find_new_server_for_Client - find unsigned int find_new_server_for_Client ( struct client *, struct service * svr) */

/*int migrate_service ( struct service *psvr , unsigned int ip_addr, unsigned short svr_port); */

int print_service_management_message(struct service_management_message * psmm) 
{

char service_name[100];
char archive_name[100];
	printf("command: %d \n", psmm->command);
	printf("service_name_len %d \n", psmm->serv_mec.service_name_len);
	strncpy(service_name, psmm->serv_mec.service_name, psmm->serv_mec.service_name_len);
	printf("service_name:%s\n",service_name);
        //char *strncpy(char *dest, const char *src, size_t n);
	printf("archive_executable_len %d \n", psmm->serv_mec.archive_executable_len);
	strncpy(archive_name, psmm->serv_mec.archive_executable, psmm->serv_mec.archive_executable_len);
	printf("archive_name:%s \n",archive_name);
	printf("service_id %d", psmm->serv_mec.service_id);
	printf("service_version: %d \n" , psmm->serv_mec.service_version);
	printf("maximum_number_servers: %d \n " , psmm->serv_mec.maximum_number_servers);
	printf("current_number_servers: %d \n " , psmm->serv_mec.current_number_servers);
	printf("service_list_count; %d \n " , psmm->serv_mec.service_server_list.count);
	printf("service_resources_required.CPU %d \n " , psmm->serv_mec.service_resources_required.CPU);
	printf("service_resources_required.memory %d \n " , psmm->serv_mec.service_resources_required.memory);
	printf("service_resources_required.network %d \n " , psmm->serv_mec.service_resources_required.network);
	printf("service_resources_required.storage %d \n " , psmm->serv_mec.service_resources_required.storage);
	printf("service_qos.latency %d \n " , psmm->serv_mec.service_qos.latency);
	printf("service_qos.bandwidth %d \n " , psmm->serv_mec.service_qos.bandwidth);
	printf("service_qos.jitter %d \n " , psmm->serv_mec.service_qos.jitter);
	printf("service_qos.reliability %d \n " , psmm->serv_mec.service_qos.reliability);
        printf("Finish printing service_management_message \n");
return 0;


 }

int main(int argc, char **argv)
{
 int sockrecv_fd, sockacc_fd;
  struct sockaddr_in csock, rsock;
  unsigned int len = sizeof(struct sockaddr_in);
  unsigned int *plen = &len;
  char cbuf[1024];
  struct service_management_message *psmm;
  int n;
  char *sname = "smf";
  char service_name[100];
  int service_name_len;
  int service_version;
  struct service *psvr;
  	


//printf("Service management framework starting up");
bzero((char *)&smf, sizeof(struct service_management_framework));
smf.smf_name_len = strlen(sname);
strncpy(smf.smf_name, sname, smf.smf_name_len);
smf.status = ACTIVE;

sleep(10);

printf("Service management framework starting up");
// #if 0
bzero((char *)&csock, sizeof(struct sockaddr_in));
  csock.sin_family = AF_INET;
  csock.sin_addr.s_addr = 0;
  csock.sin_port = htons(SERVER_PORT);

  if((sockrecv_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      printf("%s: unable to get a socket\n", argv[0]);
      exit(-1);
    }

  if((bind(sockrecv_fd, (struct sockaddr *)&csock, len)) < 0)
    {
      printf("%s: unable to bind to server's address\n", argv[0]);
      exit(-1);
    }

  if((listen(sockrecv_fd, 5)) < 0)
    {
      printf("%s: couldn't listen on this socket\n", argv[0]);
      exit(-1);
    }

for(;;)
    {  
if((sockacc_fd = accept(sockrecv_fd, (struct sockaddr *)&rsock, plen)) < 0)
    {
      printf("%s: accept failed\n", argv[0]);
      exit(-1);
    }

  printf("%s connected to client\n", argv[0]);
 
      n = recv(sockacc_fd, cbuf, 1024, 0);
      if(n <= 0 )
	{
	  printf("%s: cannot receive on this socket\n", argv[0]);
	  exit(-1);
	}
      printf("Recived %d bytes in buffer \n" , n);
      psmm = ((struct service_management_message *) cbuf);
      print_service_management_message(psmm);
    //  printf("%s",cbuf);
     
   
  switch(psmm->command)
{ 
    case REGISTER_SERVICE: 
       
    if ((register_service(&psmm -> serv_mec)) > 0)
    {
    printf(" Register service successful \n ");
    printf("No of managed services %d \n", smf.list_managed_services.count);
    printf("Printing Service Management Framework ");
    print_service_management_framework(&smf); 
    psmm->result = 0; // success
    send(sockacc_fd, cbuf, sizeof(struct service_management_message), 0);

      
    
    }
    else 
    {
     printf("Register service is not successful \n" );
    }
    break;
    case REQUEST_SERVICE:
    service_name_len = psmm->serv_mec.service_name_len;
    strncpy(service_name, psmm->serv_mec.service_name, service_name_len);
    service_version = psmm->serv_mec.service_version;
    
    //Find simple service
    if((request_service_simple(service_name, service_version, &psvr)) == 0)
	{
	 printf("Request Service Failed \n");
         send(sockacc_fd, cbuf, sizeof(struct service_management_message), 0);
 	}
    else 
      {
    printf("Server found \n");
    printf("Service_id %d \n", psvr->service_id);
    psmm->result = 0; //success
   // strncpy((void *)&psmm->serv_mec, (void *)psvr, sizeof(struct service));
   // psmm->serv_mec.service_id = psvr->service_id;
   psmm->serv_mec = *psvr;
    send(sockacc_fd, cbuf, sizeof(struct service_management_message), 0);
       }
   break;
 
  default:
     printf ("Other cases are not considered \n");
}
  close(sockacc_fd);
}
  
  close(sockrecv_fd);
// #endif

  exit(0);
}


/* serves registers service.
/* I would like a service.
smf will tell you which service to use.*/



